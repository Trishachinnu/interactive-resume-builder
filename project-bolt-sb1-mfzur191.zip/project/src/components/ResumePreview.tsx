import React from 'react';
import { Mail, Phone, MapPin, Globe, Linkedin, Calendar } from 'lucide-react';
import { ResumeData } from '../types/resume';

interface ResumePreviewProps {
  data: ResumeData;
}

export function ResumePreview({ data }: ResumePreviewProps) {
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const [year, month] = dateString.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1);
    return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  };

  return (
    <div id="resume-content" className="bg-white p-8 shadow-lg max-w-[8.5in] mx-auto" style={{ minHeight: '11in' }}>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          {data.personalInfo.fullName || 'Your Name'}
        </h1>
        
        <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
          {data.personalInfo.email && (
            <div className="flex items-center">
              <Mail size={14} className="mr-1" />
              {data.personalInfo.email}
            </div>
          )}
          {data.personalInfo.phone && (
            <div className="flex items-center">
              <Phone size={14} className="mr-1" />
              {data.personalInfo.phone}
            </div>
          )}
          {data.personalInfo.location && (
            <div className="flex items-center">
              <MapPin size={14} className="mr-1" />
              {data.personalInfo.location}
            </div>
          )}
          {data.personalInfo.website && (
            <div className="flex items-center">
              <Globe size={14} className="mr-1" />
              <a href={data.personalInfo.website} className="text-blue-600 hover:underline">
                {data.personalInfo.website.replace(/^https?:\/\//, '')}
              </a>
            </div>
          )}
          {data.personalInfo.linkedin && (
            <div className="flex items-center">
              <Linkedin size={14} className="mr-1" />
              <a href={data.personalInfo.linkedin} className="text-blue-600 hover:underline">
                LinkedIn
              </a>
            </div>
          )}
        </div>
        
        {data.personalInfo.summary && (
          <p className="text-gray-700 leading-relaxed">
            {data.personalInfo.summary}
          </p>
        )}
      </div>

      {/* Experience */}
      {data.experience.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4 pb-2 border-b-2 border-blue-600">
            Work Experience
          </h2>
          <div className="space-y-6">
            {data.experience.map((exp) => (
              <div key={exp.id}>
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">
                      {exp.position || 'Position Title'}
                    </h3>
                    <p className="text-blue-600 font-medium">
                      {exp.company || 'Company Name'}
                    </p>
                  </div>
                  <div className="text-sm text-gray-600 flex items-center">
                    <Calendar size={14} className="mr-1" />
                    {formatDate(exp.startDate)} - {exp.current ? 'Present' : formatDate(exp.endDate)}
                  </div>
                </div>
                {exp.description && (
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                    {exp.description}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Education */}
      {data.education.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4 pb-2 border-b-2 border-blue-600">
            Education
          </h2>
          <div className="space-y-4">
            {data.education.map((edu) => (
              <div key={edu.id} className="flex justify-between items-start">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    {edu.degree || 'Degree'} in {edu.field || 'Field of Study'}
                  </h3>
                  <p className="text-blue-600 font-medium">
                    {edu.school || 'School Name'}
                  </p>
                  {edu.gpa && (
                    <p className="text-sm text-gray-600">GPA: {edu.gpa}</p>
                  )}
                </div>
                <div className="text-sm text-gray-600 flex items-center">
                  <Calendar size={14} className="mr-1" />
                  {formatDate(edu.graduationDate)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Skills */}
      {data.skills.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4 pb-2 border-b-2 border-blue-600">
            Skills
          </h2>
          <div className="grid grid-cols-2 gap-4">
            {data.skills.map((skill) => (
              <div key={skill.id} className="flex justify-between items-center">
                <span className="text-gray-700">{skill.name || 'Skill'}</span>
                <span className="text-sm text-blue-600 font-medium">{skill.level}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}